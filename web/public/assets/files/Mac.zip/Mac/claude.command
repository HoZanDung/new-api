#!/bin/bash
# 双击此文件即可启动 Claude Code

# 刷新 brew PATH（兼容 Apple Silicon / Intel）
if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# 加载 shell 配置（确保 npm、python 等路径已生效）
PROFILE="$HOME/.zprofile"
[ "$SHELL" != "/bin/zsh" ] && PROFILE="$HOME/.bash_profile"
[ -f "$PROFILE" ] && source "$PROFILE" 2>/dev/null

# 动态追加 npm 全局 bin（防止 source 后仍找不到 claude）
if command -v npm &> /dev/null; then
    export PATH="$(npm config get prefix)/bin:$PATH"
fi

# ── 检测 claude，没有则运行安装程序 ──────────────
if ! command -v claude &> /dev/null; then
    echo "未检测到 Claude Code，正在启动安装程序..."
    echo ""
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    # 用当前 shell 执行（不是子进程），这样 PATH 变更可以传回来
    source "$SCRIPT_DIR/setup.command" || {
        echo "❌ setup.command 执行失败"
        read -p "按回车键退出..."
        exit 1
    }

    # 安装后多次刷新，确保路径完全生效
    [ -f /opt/homebrew/bin/brew ] && eval "$(/opt/homebrew/bin/brew shellenv)"
    [ -f /usr/local/bin/brew ]    && eval "$(/usr/local/bin/brew shellenv)"
    [ -f "$PROFILE" ] && source "$PROFILE" 2>/dev/null
    command -v npm &>/dev/null && export PATH="$(npm config get prefix)/bin:$PATH"
    command -v python3 &>/dev/null && export PATH="$(python3 -m site --user-base)/bin:$PATH"

    if ! command -v claude &> /dev/null; then
        echo ""
        echo "❌ 安装未成功，请手动运行 setup.command 排查"
        read -p "按回车键退出..."
        exit 1
    fi
fi

# ── 启动 Claude Code ────────────────────────────
cd ~
claude
