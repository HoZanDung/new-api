﻿#Requires -Version 5.0
# Claude Code 环境安装程序 (Windows)

# ── 自动提升管理员权限 ──────────────────────────────────────────────────
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process PowerShell -Verb RunAs `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Continue'

# ── 常量 ─────────────────────────────────────────────────────────────────
$REQ_NODE_MAJOR = 18
$REQ_GIT_MAJOR  = 2;  $REQ_GIT_MINOR = 23
$REQ_PY_MAJOR   = 3;  $REQ_PY_MINOR  = 8
$NODE_VER       = 'v20.18.0'
$MIRROR_NPM     = 'https://registry.npmmirror.com'
$MIRROR_NODE    = "https://npmmirror.com/mirrors/node/$NODE_VER"
$BASE_URL       = 'http://xxopus.cc'
$MODEL          = 'xxopus-model'

# ── 工具函数 ─────────────────────────────────────────────────────────────
function Has([string]$cmd) {
    $null -ne (Get-Command $cmd -ErrorAction SilentlyContinue)
}

function Add-UserPath([string]$p) {
    if (-not (Test-Path $p)) { Write-Host "  路径不存在，跳过: $p"; return }
    $cur = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($null -eq $cur) { $cur = '' }
    $parts = $cur -split ';' | Where-Object { $_ -ne '' }
    if ($parts -icontains $p) { Write-Host "  PATH 已包含: $p"; return }
    [Environment]::SetEnvironmentVariable('Path', (($parts + $p) -join ';'), 'User')
    $env:PATH = "$env:PATH;$p"
    Write-Host "  已添加 PATH: $p"
}

function Set-UEnv([string]$n, [string]$v) {
    [Environment]::SetEnvironmentVariable($n, $v, 'User')
    [System.Environment]::SetEnvironmentVariable($n, $v)
    Write-Host "  已设置: $n"
}

function Read-SecureToken([string]$prompt) {
    $s = Read-Host -AsSecureString $prompt
    if ($null -eq $s -or $s.Length -eq 0) { return '' }
    $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
    try   { return [Runtime.InteropServices.Marshal]::PtrToStringAuto($b) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}

function Get-Status([int]$n) {
    if ($n -eq 0) { '○  已存在' } elseif ($n -eq 1) { '✅ 新安装' } elseif ($n -eq 2) { '✅ 已升级' } else { '❌ 安装失败' }
}

function Cmp-Version([int]$maj, [int]$min, [int]$rMaj, [int]$rMin) {
    if ($maj -gt $rMaj) { return 1 }
    if ($maj -eq $rMaj -and $min -ge $rMin) { return 0 }
    return -1
}

# ── 主流程 ───────────────────────────────────────────────────────────────
Write-Host ''
Write-Host '============================================' -ForegroundColor Cyan
Write-Host '    Claude Code 环境安装程序 (Windows)'      -ForegroundColor Cyan
Write-Host '============================================' -ForegroundColor Cyan
Write-Host ''

# ── 第一步：扫描环境 ──────────────────────────────────────────────────────
Write-Host '【第一步】扫描已有环境...' -ForegroundColor Yellow
Write-Host '----------------------------------------'

$needGit    = 0   # 0=满足  1=未安装  2=需升级
$needNode   = 0
$needPython = 0
$needClaude = 0

# Git
if (Has 'git') {
    $v   = (git --version) -replace 'git version ', ''
    if ($v -match '(\d+)\.(\d+)') { $maj = [int]$Matches[1]; $min = [int]$Matches[2] }
    else { $maj = 0; $min = 0 }
    if ((Cmp-Version $maj $min $REQ_GIT_MAJOR $REQ_GIT_MINOR) -ge 0) {
        Write-Host "✅ Git        $v"
    } else {
        Write-Host "⚠️  Git        $v  (过低，需 >= $REQ_GIT_MAJOR.$REQ_GIT_MINOR，将升级)"
        $needGit = 2
    }
} else {
    Write-Host '❌ Git        未安装'
    $needGit = 1
}

# Node.js
if (Has 'node') {
    $v   = (node --version) -replace '^v', ''
    if ($v -match '(\d+)') { $maj = [int]$Matches[1] } else { $maj = 0 }
    if ($maj -ge $REQ_NODE_MAJOR) {
        Write-Host "✅ Node.js    v$v"
    } else {
        Write-Host "⚠️  Node.js    v$v  (过低，需 >= $REQ_NODE_MAJOR，将升级)"
        $needNode = 2
    }
} else {
    Write-Host '❌ Node.js    未安装'
    $needNode = 1
}

# Python
if (Has 'python') {
    $vl = (python --version 2>&1) -join ''
    if ($vl -match '(\d+)\.(\d+)') {
        $maj = [int]$Matches[1]; $min = [int]$Matches[2]
        if ((Cmp-Version $maj $min $REQ_PY_MAJOR $REQ_PY_MINOR) -ge 0) {
            Write-Host "✅ Python     $maj.$min"
        } else {
            Write-Host "⚠️  Python     $maj.$min  (过低，需 >= $REQ_PY_MAJOR.$REQ_PY_MINOR，将升级)"
            $needPython = 2
        }
    }
} else {
    Write-Host '❌ Python     未安装'
    $needPython = 1
}

# Claude Code
if (Has 'claude') {
    $v = (& claude --version 2>$null) -join ''
    Write-Host "✅ Claude Code $v (已安装，将检查更新)"
    $needClaude = 2
} else {
    Write-Host '❌ Claude Code 未安装'
    $needClaude = 1
}
Write-Host ''

# ── 第二步：安装/升级 ────────────────────────────────────────────────────
Write-Host '【第二步】安装 / 升级...' -ForegroundColor Yellow
Write-Host '----------------------------------------'

$hasWinget = Has 'winget'
if ($hasWinget) {
    Write-Host '✅ 检测到 winget，将用于安装 Git / Python'
} else {
    Write-Host '○  未检测到 winget，Node.js 将从淘宝镜像直接下载，Git/Python 请手动安装'
}

$failed = $false

# Git
if ($needGit -eq 1) {
    if ($hasWinget) {
        Write-Host "`n📦 安装 Git..."
        winget install --id Git.Git -e --source winget
        if ($LASTEXITCODE -ne 0) { Write-Host '⚠️  Git 安装失败'; $failed = $true; $needGit = -1 }
    } else {
        Write-Host "`n📦 安装 Git (清华镜像直接下载)..."
        try {
            $mirror  = 'https://mirrors.tuna.tsinghua.edu.cn/github-release/git-for-windows/git/LatestRelease/'
            $page    = Invoke-WebRequest $mirror -UseBasicParsing -TimeoutSec 15
            $gitFile = [regex]::Match($page.Content, 'href="(Git-[\d.]+-64-bit\.exe)"').Groups[1].Value
            if (-not $gitFile) { throw '未找到安装包链接' }
            $gitUrl  = $mirror + $gitFile
            $gitInst = "$env:TEMP\git-inst.exe"
            Invoke-WebRequest $gitUrl -OutFile $gitInst -UseBasicParsing -TimeoutSec 180
            Start-Process $gitInst -Wait -ArgumentList '/VERYSILENT /NORESTART /NOCANCEL /SP-'
            Write-Host '✅ Git 安装完成'
        } catch {
            Write-Host "⚠️  Git 自动安装失败: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host '   请手动下载后重新运行 setup.bat：'
            Write-Host '   https://mirrors.tuna.tsinghua.edu.cn/github-release/git-for-windows/git/LatestRelease/' -ForegroundColor Cyan
            $failed = $true; $needGit = -1
        }
    }
} elseif ($needGit -eq 2 -and $hasWinget) {
    Write-Host "`n📦 升级 Git..."
    winget upgrade --id Git.Git -e --source winget
}

# Node.js
if ($needNode -eq 1) {
    $nodeInstalled = $false
    if ($hasWinget) {
        Write-Host "`n📦 安装 Node.js LTS (winget)..."
        winget install --id OpenJS.NodeJS.LTS -e --source winget
        $nodeInstalled = ($LASTEXITCODE -eq 0)
        if (-not $nodeInstalled) { Write-Host '⚠️  winget 安装失败，切换为直接下载...' }
    }
    if (-not $nodeInstalled) {
        Write-Host "`n📦 安装 Node.js LTS (淘宝镜像直接下载)..."
        $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
        $msi  = "$env:TEMP\node-inst.msi"
        try {
            Invoke-WebRequest "$MIRROR_NODE/node-$NODE_VER-$arch.msi" `
                -OutFile $msi -UseBasicParsing -TimeoutSec 120
            $proc = Start-Process msiexec.exe -PassThru -Wait -ArgumentList "/I `"$msi`" /quiet /norestart"
            if ($proc.ExitCode -notin 0, 3010) { throw "msiexec 退出码 $($proc.ExitCode)" }
            Write-Host '✅ Node.js 安装完成'
            if ($proc.ExitCode -eq 3010) { Write-Host '  (安装成功，重启后生效)' }
        } catch {
            Write-Host "⚠️  Node.js 安装失败: $($_.Exception.Message)"
            Write-Host "   请手动下载: $MIRROR_NODE/"
            $failed = $true; $needNode = -1
        }
    }
} elseif ($needNode -eq 2 -and $hasWinget) {
    Write-Host "`n📦 升级 Node.js..."
    winget upgrade --id OpenJS.NodeJS.LTS -e --source winget
}

# Python
if ($needPython -eq 1) {
    if ($hasWinget) {
        Write-Host "`n📦 安装 Python3..."
        winget install --id Python.Python.3 -e --source winget `
            --override '/quiet InstallAllUsers=0 PrependPath=1'
        if ($LASTEXITCODE -ne 0) { Write-Host '⚠️  Python 安装失败'; $failed = $true; $needPython = -1 }
    } else {
        Write-Host '○  Python：请手动安装 https://www.python.org/downloads/'
        $needPython = -1
    }
} elseif ($needPython -eq 2 -and $hasWinget) {
    Write-Host "`n📦 升级 Python3..."
    winget upgrade --id Python.Python.3 -e --source winget
}

Write-Host ''

# ── 第三步：配置环境变量 ──────────────────────────────────────────────────
Write-Host '【第三步】配置环境变量...' -ForegroundColor Yellow
Write-Host '----------------------------------------'

Add-UserPath "$env:APPDATA\npm"
Add-UserPath "$env:ProgramFiles\nodejs"
Add-UserPath "$env:ProgramFiles\Git\cmd"
Set-UEnv 'NPM_CONFIG_REGISTRY' $MIRROR_NPM

# Python 路径
$pyCmd = Get-Command python -ErrorAction SilentlyContinue
if ($pyCmd) {
    $pyDir = Split-Path $pyCmd.Source
    Add-UserPath $pyDir
    Add-UserPath "$pyDir\Scripts"
} else {
    $pyBase = "$env:LOCALAPPDATA\Programs\Python"
    if (Test-Path $pyBase) {
        $latest = Get-ChildItem $pyBase -Directory |
                  Where-Object { $_.Name -match 'Python\d+' } |
                  Sort-Object { [int]($_.Name -replace '\D', '') } -Descending |
                  Select-Object -First 1
        if ($latest) {
            Add-UserPath $latest.FullName
            Add-UserPath "$($latest.FullName)\Scripts"
        }
    } else {
        Write-Host '  Python 未找到，跳过'
    }
}

# pip 镜像
$pipDir  = "$env:APPDATA\pip"
$pipConf = "$pipDir\pip.ini"
if (-not (Test-Path $pipDir)) { New-Item -ItemType Directory -Path $pipDir -Force | Out-Null }
$existing = if (Test-Path $pipConf) { Get-Content $pipConf -Raw } else { '' }
if ($existing -notlike '*mirrors*') {
    "[global]`nindex-url = https://mirrors.aliyun.com/pypi/simple/`ntrusted-host = mirrors.aliyun.com" |
        Set-Content $pipConf -Encoding UTF8
    Write-Host "  已写入 pip 镜像: $pipConf"
} else {
    Write-Host '  pip 镜像已配置，跳过'
}

# 刷新当前 session PATH
$env:PATH = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
            [Environment]::GetEnvironmentVariable('Path', 'User') + ';' +
            "$env:APPDATA\npm;$env:ProgramFiles\nodejs"
Write-Host ''

# ── 第四步：安装/更新 Claude Code ────────────────────────────────────────
Write-Host '【第四步】安装 / 更新 Claude Code...' -ForegroundColor Yellow
Write-Host '----------------------------------------'

$npmCmd = if (Has 'npm') { 'npm' }
          elseif (Test-Path "$env:ProgramFiles\nodejs\npm.cmd") { "$env:ProgramFiles\nodejs\npm.cmd" }
          else { $null }

if (-not $npmCmd) {
    Write-Host '⚠️  npm 仍未找到（Node.js 安装后需重启才能生效）'
    Write-Host '   请重启电脑后再次运行此脚本'
    $failed = $true
} else {
    & $npmCmd config set registry $MIRROR_NPM | Out-Null
    $env:NPM_CONFIG_REGISTRY = $MIRROR_NPM

    if ($needClaude -eq 1) {
        Write-Host '📦 安装 Claude Code (淘宝镜像)...'
        & $npmCmd install -g @anthropic-ai/claude-code --registry $MIRROR_NPM
        if (-not (Has 'claude')) {
            Write-Host '⚠️  淘宝镜像失败，尝试官方源...'
            & $npmCmd install -g @anthropic-ai/claude-code
            if (-not (Has 'claude')) { $failed = $true; $needClaude = -1 }
        }
    } elseif ($needClaude -eq 2) {
        Write-Host '📦 更新 Claude Code (淘宝镜像)...'
        & $npmCmd update -g @anthropic-ai/claude-code --registry $MIRROR_NPM
    }

    # 配置 Anthropic 环境变量
    Write-Host ''
    $curToken = [Environment]::GetEnvironmentVariable('ANTHROPIC_AUTH_TOKEN', 'User')
    if ($curToken) {
        Write-Host '   已检测到 ANTHROPIC_AUTH_TOKEN'
        $c = Read-Host '  是否要更新 Token？(y/N)'
        if ($c -eq 'y' -or $c -eq 'Y') {
            $t = Read-SecureToken '  请输入新 Token（输入时不显示）'
            if ($t) { Set-UEnv 'ANTHROPIC_AUTH_TOKEN' $t; Write-Host '   Token 已更新' }
            else     { Write-Host '   未输入，保持原有 Token' }
        } else {
            Write-Host '   保持原有 Token'
        }
    } else {
        $t = Read-SecureToken '  请输入 ANTHROPIC_AUTH_TOKEN（公司 API Key，输入时不显示）'
        if ($t) { Set-UEnv 'ANTHROPIC_AUTH_TOKEN' $t; Write-Host '   已写入' }
        else     { Write-Host '   未输入，跳过（需手动配置 ANTHROPIC_AUTH_TOKEN）' }
    }

    Set-UEnv 'ANTHROPIC_BASE_URL'                      $BASE_URL
    Set-UEnv 'ANTHROPIC_MODEL'                         $MODEL
    Set-UEnv 'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS' '1'
    Write-Host '   公司参数已写入'
}
Write-Host ''

# ── 第五步：验证汇总 ──────────────────────────────────────────────────────
Write-Host '【第五步】环境验证汇总' -ForegroundColor Yellow
Write-Host '----------------------------------------'
foreach ($cmd in 'git', 'node', 'npm', 'python', 'claude') {
    if (Has $cmd) { Write-Host "  ✅ $($cmd.PadRight(10))" }
    else           { Write-Host "  ❌ $($cmd.PadRight(10)) 未找到" }
}
Write-Host ''
Write-Host "  npm 镜像：$MIRROR_NPM"
Write-Host '  pip 镜像：阿里云'
Write-Host ''
Write-Host '============================================' -ForegroundColor Cyan
if ((Has 'claude') -and (Has 'git') -and -not $failed) {
    Write-Host '    ✅ 全部完成！双击 claude.bat 即可启动' -ForegroundColor Green
    Write-Host '    建议重新打开终端让环境变量完全生效'    -ForegroundColor Green
} elseif (-not (Has 'git')) {
    Write-Host '    ❌ Git 未安装，Claude Code 无法运行'   -ForegroundColor Red
    Write-Host '    请手动安装 Git 后重新运行 setup.bat：' -ForegroundColor Red
    Write-Host '    https://git-scm.com/download/win'      -ForegroundColor Cyan
} elseif (Has 'claude') {
    Write-Host '    ⚠️  Claude Code 已安装，但部分组件安装失败' -ForegroundColor Yellow
    Write-Host '    建议重启电脑后重新运行此脚本'               -ForegroundColor Yellow
} else {
    Write-Host '    ❌ 安装未完成，请重启电脑后再次运行此脚本' -ForegroundColor Red
}
Write-Host '============================================' -ForegroundColor Cyan
Write-Host ''

# 安装总结
Write-Host '----------------------------------------'
Write-Host '  安装总结'
Write-Host '----------------------------------------'
Write-Host "  Git:         $(Get-Status $needGit)"
Write-Host "  Node.js:     $(Get-Status $needNode)"
Write-Host "  Python:      $(Get-Status $needPython)"
Write-Host "  Claude Code: $(Get-Status $needClaude)"
Write-Host ''
Write-Host '  如需清理：双击 uninstall.bat'
Write-Host '----------------------------------------'
Write-Host ''
Read-Host '按回车键关闭'
