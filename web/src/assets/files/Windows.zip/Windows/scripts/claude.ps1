﻿# Claude Code 启动器

chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 从注册表刷新 PATH（确保已安装的工具能被找到）
$macPath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
$usrPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$env:PATH = "$macPath;$usrPath"

# 同步用户级环境变量到当前 session
foreach ($name in 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL',
                  'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS', 'NPM_CONFIG_REGISTRY') {
    $v = [Environment]::GetEnvironmentVariable($name, 'User')
    if ($v) { [System.Environment]::SetEnvironmentVariable($name, $v) }
}

# 检查 claude 命令是否存在
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
    Write-Host '❌ 未检测到 Claude Code，请先双击 setup.bat 完成安装' -ForegroundColor Red
    Write-Host ''
    Write-Host '    安装问题请联系客服vx：dengyi_dance' -ForegroundColor Yellow
    Read-Host '按回车键退出'
    exit 1
}

# 启动 Claude Code
Set-Location $env:USERPROFILE
& claude
$code = $LASTEXITCODE

if ($code -ne 0) {
    Write-Host "`n❌ Claude 异常退出（错误码 $code），如持续出现请重新运行 setup.bat"
}
Read-Host '按回车键关闭'
