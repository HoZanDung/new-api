﻿# Claude Code 启动器

chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 从注册表刷新 PATH（确保已安装的工具能被找到）
$macPath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
$usrPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$env:PATH = "$macPath;$usrPath"

# 同步用户级环境变量到当前 session
foreach ($name in 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL',
                  'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS', 'NPM_CONFIG_REGISTRY') {
    $v = [Environment]::GetEnvironmentVariable($name, 'User')
    if ($v) { [System.Environment]::SetEnvironmentVariable($name, $v) }
}

# 检查 claude 命令是否存在，否则运行安装程序
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
    Write-Host '未检测到 Claude Code，正在启动安装程序...'
    Write-Host ''
    $setup = Join-Path $PSScriptRoot 'setup.ps1'
    if (Test-Path $setup) {
        # 用 -Verb RunAs -Wait 直接启动提升进程并等待其完成
        # 不能用 & powershell：setup.ps1 会立即 exit 去开提升子进程，导致父进程误判安装完成
        try {
            Start-Process PowerShell -Wait -Verb RunAs `
                -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$setup`""
        } catch {
            Write-Host '⚠️  未获得管理员权限，安装已取消'
            Read-Host '按回车键退出'
            exit 1
        }
    } else {
        Write-Host "❌ 找不到安装程序: $setup"
        Read-Host '按回车键退出'
        exit 1
    }

    # 安装后重新刷新 PATH
    $macPath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $usrPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:PATH = "$macPath;$usrPath"

    if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
        Write-Host '❌ 安装未成功，请重启电脑后再试，或手动运行 setup.bat 排查'
        Read-Host '按回车键退出'
        exit 1
    }
}

# 启动 Claude Code
Set-Location $env:USERPROFILE
& claude
$code = $LASTEXITCODE

if ($code -ne 0) {
    Write-Host "`n❌ Claude 异常退出（错误码 $code），如持续出现请重新运行 setup.bat"
}
Read-Host '按回车键关闭'
