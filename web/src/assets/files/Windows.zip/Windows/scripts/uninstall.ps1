﻿#Requires -Version 5.0
# Claude Code 卸载程序 (Windows)

# ── 自动提升管理员权限 ──────────────────────────────────────────────────
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process PowerShell -Verb RunAs `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host ''
Write-Host '============================================' -ForegroundColor Cyan
Write-Host '    Claude Code 卸载程序 (Windows)'          -ForegroundColor Cyan
Write-Host '============================================' -ForegroundColor Cyan
Write-Host ''

# ── 第一步：卸载 Claude Code ──────────────────────────────────────────────
Write-Host '【第一步】卸载 Claude Code...' -ForegroundColor Yellow
if (Get-Command claude -ErrorAction SilentlyContinue) {
    npm uninstall -g @anthropic-ai/claude-code
    Write-Host '✅ Claude Code 已卸载'
} else {
    Write-Host '   Claude Code 未安装，跳过'
}
Write-Host ''

# ── 第二步：清理环境变量 ──────────────────────────────────────────────────
Write-Host '【第二步】清理环境变量...' -ForegroundColor Yellow
foreach ($name in 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL',
                  'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS', 'NPM_CONFIG_REGISTRY') {
    [Environment]::SetEnvironmentVariable($name, $null, 'User')
    Write-Host "  已清理: $name"
}

# 从 PATH 移除 npm 路径
$npmPath = "$env:APPDATA\npm"
$p = [Environment]::GetEnvironmentVariable('Path', 'User')
if ($p) {
    $cleaned = ($p -split ';' | Where-Object { $_ -ne $npmPath }) -join ';'
    [Environment]::SetEnvironmentVariable('Path', $cleaned, 'User')
    Write-Host "  已从 PATH 移除: $npmPath"
}
Write-Host ''

# ── 第三步：清理 pip 镜像 ─────────────────────────────────────────────────
Write-Host '【第三步】清理 pip 镜像配置...' -ForegroundColor Yellow
$pipConf = "$env:APPDATA\pip\pip.ini"
if (Test-Path $pipConf) {
    $content = Get-Content $pipConf -Raw
    if ($content -like '*aliyun*') {
        Remove-Item $pipConf -Force
        Write-Host '✅ pip 镜像配置已清理'
    } else {
        Write-Host '   pip 镜像不是由本脚本配置，跳过'
    }
} else {
    Write-Host '   pip.ini 不存在，跳过'
}
Write-Host ''

# ── 第四步：可选卸载工具 ──────────────────────────────────────────────────
Write-Host '【第四步】以下工具是否需要卸载？（直接回车默认保留）' -ForegroundColor Yellow
Write-Host ''

if (Get-Command python -ErrorAction SilentlyContinue) {
    $c = Read-Host '  是否卸载 Python？(y/N)'
    if ($c -eq 'y' -or $c -eq 'Y') {
        winget uninstall --id Python.Python.3 -e
        Write-Host '✅ Python 已卸载'
    } else { Write-Host '   保留 Python' }
}

if (Get-Command node -ErrorAction SilentlyContinue) {
    $c = Read-Host '  是否卸载 Node.js？(y/N)'
    if ($c -eq 'y' -or $c -eq 'Y') {
        winget uninstall --id OpenJS.NodeJS.LTS -e
        Write-Host '✅ Node.js 已卸载'
    } else { Write-Host '   保留 Node.js' }
}

if (Get-Command git -ErrorAction SilentlyContinue) {
    $c = Read-Host '  是否卸载 Git？(y/N)'
    if ($c -eq 'y' -or $c -eq 'Y') {
        winget uninstall --id Git.Git -e
        Write-Host '✅ Git 已卸载'
    } else { Write-Host '   保留 Git' }
}

Write-Host ''
Write-Host '============================================' -ForegroundColor Cyan
Write-Host '    ✅ 卸载完成！'                            -ForegroundColor Green
Write-Host '    建议重启电脑让配置完全生效'               -ForegroundColor Green
Write-Host '============================================' -ForegroundColor Cyan
Write-Host ''
Read-Host '按回车键关闭'
