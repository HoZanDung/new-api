#!/bin/bash
# 双击此文件即可启动 Claude Code

# 刷新 brew PATH（兼容 Apple Silicon / Intel）
if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# 加载 shell 配置（确保 npm、python 等路径已生效）
PROFILE="$HOME/.zprofile"
[ "$SHELL" != "/bin/zsh" ] && PROFILE="$HOME/.bash_profile"
[ -f "$PROFILE" ] && source "$PROFILE" 2>/dev/null
[ -f "$HOME/.zshrc" ] && source "$HOME/.zshrc" 2>/dev/null

# 动态追加 npm 全局 bin（防止 source 后仍找不到 claude）
if command -v npm &> /dev/null; then
    export PATH="$(npm config get prefix)/bin:$PATH"
fi

# ── 检测 claude ──────────────────────────────────
if ! command -v claude &> /dev/null; then
    echo "❌ 未检测到 Claude Code，请先双击 setup.command 完成安装"
    echo ""
    echo "    安装问题请联系客服vx：dengyi_dance"
    read -p "按回车键退出..."
    exit 1
fi

# ── 启动 Claude Code ────────────────────────────
cd ~
claude
