#!/bin/bash
# Claude Code 卸载程序 (Mac)

echo "============================================"
echo "    Claude Code 卸载程序 (Mac)"
echo "============================================"
echo ""

get_profile() {
    if [ "$SHELL" = "/bin/zsh" ] || [ -n "$ZSH_VERSION" ]; then
        echo "$HOME/.zshrc"
    else
        echo "$HOME/.bash_profile"
    fi
}
PROFILE=$(get_profile)

# ════════════════════════════════════════════════
# 第一步：卸载 Claude Code
# ════════════════════════════════════════════════
echo "【第一步】卸载 Claude Code..."
if command -v claude &>/dev/null; then
    npm uninstall -g @anthropic-ai/claude-code
    echo "✅ Claude Code 已卸载"
else
    echo "   Claude Code 未安装，跳过"
fi
echo ""

# ════════════════════════════════════════════════
# 第二步：清理环境变量
# ════════════════════════════════════════════════
echo "【第二步】清理环境变量（$PROFILE）..."
if [ -f "$PROFILE" ]; then
    sed -i '' '/# Claude Code 环境配置/d' "$PROFILE"
    sed -i '' '/ANTHROPIC_AUTH_TOKEN/d' "$PROFILE"
    sed -i '' '/ANTHROPIC_BASE_URL/d' "$PROFILE"
    sed -i '' '/ANTHROPIC_MODEL/d' "$PROFILE"
    sed -i '' '/CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS/d' "$PROFILE"
    sed -i '' '/HOMEBREW_BREW_GIT_REMOTE/d' "$PROFILE"
    sed -i '' '/HOMEBREW_CORE_GIT_REMOTE/d' "$PROFILE"
    sed -i '' '/HOMEBREW_BOTTLE_DOMAIN/d' "$PROFILE"
    sed -i '' '/HOMEBREW_API_DOMAIN/d' "$PROFILE"
    sed -i '' '/npm config get prefix/d' "$PROFILE"
    sed -i '' '/NPM_CONFIG_REGISTRY/d' "$PROFILE"
    sed -i '' '/python3 -m site --user-base/d' "$PROFILE"
    echo "✅ 环境变量已清理"
else
    echo "   未找到 $PROFILE，跳过"
fi
echo ""

# ════════════════════════════════════════════════
# 第三步：清理 pip 镜像配置
# ════════════════════════════════════════════════
echo "【第三步】清理 pip 镜像配置..."
PIP_CONF="$HOME/.pip/pip.conf"
if grep -q "aliyun" "$PIP_CONF" 2>/dev/null; then
    rm -f "$PIP_CONF"
    echo "✅ ~/.pip/pip.conf 已清理"
else
    echo "   pip 镜像不是由本脚本配置，跳过"
fi
echo ""

# ════════════════════════════════════════════════
# 第四步：可选卸载其他工具（默认保留）
# ════════════════════════════════════════════════
echo "【第四步】以下工具是否需要卸载？（直接回车默认保留）"
echo ""

if command -v python3 &>/dev/null; then
    read -r -n 1 -p "  是否卸载 Python3？(y/N) " CHOICE; echo ""
    if [[ "$CHOICE" =~ ^[Yy]$ ]]; then
        brew uninstall python3 2>/dev/null && echo "✅ Python3 已卸载" || echo "   ⚠️ 卸载失败（可能不是通过 brew 安装的）"
    else
        echo "   保留 Python3"
    fi
fi

if command -v node &>/dev/null; then
    read -r -n 1 -p "  是否卸载 Node.js？(y/N) " CHOICE; echo ""
    if [[ "$CHOICE" =~ ^[Yy]$ ]]; then
        brew uninstall node 2>/dev/null && echo "✅ Node.js 已卸载" || echo "   ⚠️ 卸载失败（可能不是通过 brew 安装的）"
    else
        echo "   保留 Node.js"
    fi
fi

if command -v git &>/dev/null; then
    read -r -n 1 -p "  是否卸载 Git？(y/N) " CHOICE; echo ""
    if [[ "$CHOICE" =~ ^[Yy]$ ]]; then
        brew uninstall git 2>/dev/null && echo "✅ Git 已卸载" || echo "   ⚠️ 卸载失败（可能不是通过 brew 安装的）"
    else
        echo "   保留 Git"
    fi
fi

if command -v brew &>/dev/null; then
    read -r -n 1 -p "  是否卸载 Homebrew？(y/N) " CHOICE; echo ""
    if [[ "$CHOICE" =~ ^[Yy]$ ]]; then
        sed -i '' '/brew shellenv/d' "$PROFILE"
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/uninstall.sh)"
        echo "✅ Homebrew 已卸载"
    else
        echo "   保留 Homebrew"
    fi
fi

echo ""
echo "============================================"
echo "    ✅ 卸载完成！"
echo "    建议重新打开终端让配置完全生效"
echo "============================================"
echo ""
read -p "按回车键退出..."
