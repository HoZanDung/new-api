#!/bin/bash
# Claude Code 环境检查 & 安装 & 配置 (Mac)

echo "============================================"
echo "    Claude Code 环境安装程序 (Mac)"
echo "============================================"
echo ""

# ════════════════════════════════════════════════
# 工具函数
# ════════════════════════════════════════════════

version_ge() {
    [ "$(printf '%s\n' "$1" "$2" | sort -V | head -1)" = "$2" ]
}

get_profile() {
    if [ "$SHELL" = "/bin/zsh" ] || [ -n "$ZSH_VERSION" ]; then
        echo "$HOME/.zshrc"
    else
        echo "$HOME/.bash_profile"
    fi
}
PROFILE=$(get_profile)

# 安全写入配置（避免重复）
add_to_profile() {
    local marker="$1"
    local content="$2"
    if grep -qF "$marker" "$PROFILE" 2>/dev/null; then
        echo "   ↳ 已配置，跳过"
    else
        printf "\n%s\n" "$content" >> "$PROFILE"
        echo "   ↳ 已写入 $PROFILE"
    fi
}

# 刷新当前 session 的 brew PATH（Apple Silicon / Intel 自动判断）
refresh_brew_path() {
    if [ -f /opt/homebrew/bin/brew ]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    elif [ -f /usr/local/bin/brew ]; then
        eval "$(/usr/local/bin/brew shellenv)"
    fi
}

# 检测芯片类型：优先看 brew 实际安装在哪，其次看 uname -m
if [ -f /opt/homebrew/bin/brew ]; then
    BREW_PREFIX="/opt/homebrew"
    CHIP="Apple Silicon (M系列)"
elif [ -f /usr/local/bin/brew ]; then
    BREW_PREFIX="/usr/local"
    CHIP="Intel"
elif [[ $(uname -m) == "arm64" ]]; then
    BREW_PREFIX="/opt/homebrew"
    CHIP="Apple Silicon (M系列)"
else
    BREW_PREFIX="/usr/local"
    CHIP="Intel"
fi

echo "  芯片类型：$CHIP"
echo "  Shell配置：$PROFILE"
echo ""

# 版本最低要求
REQ_NODE="18.0.0"
REQ_GIT="2.23.0"
REQ_PYTHON="3.8.0"

# 提前刷新 brew PATH（如果已安装）
refresh_brew_path

# ════════════════════════════════════════════════
# 第一步：扫描已有环境
# ════════════════════════════════════════════════
echo "【第一步】扫描已有环境..."
echo "────────────────────────────────────────"

NEED_BREW=false
NEED_GIT=false
NEED_NODE=false
NEED_PYTHON=false
NEED_CLAUDE=false

if command -v brew &> /dev/null; then
    echo "✅ Homebrew   $(brew --version | head -1)"
else
    echo "❌ Homebrew   未安装"
    NEED_BREW=true
fi

if command -v git &> /dev/null; then
    GIT_VER=$(git --version | awk '{print $3}')
    if version_ge "$GIT_VER" "$REQ_GIT"; then
        echo "✅ Git        $GIT_VER（满足 ≥$REQ_GIT）"
    else
        echo "⚠️  Git        $GIT_VER（过低，需 ≥$REQ_GIT，将升级）"
        NEED_GIT=upgrade
    fi
else
    echo "❌ Git        未安装"
    NEED_GIT=install
fi

if command -v node &> /dev/null; then
    NODE_VER=$(node --version | sed 's/v//')
    if version_ge "$NODE_VER" "$REQ_NODE"; then
        echo "✅ Node.js    $NODE_VER（满足 ≥$REQ_NODE）"
    else
        echo "⚠️  Node.js    $NODE_VER（过低，需 ≥$REQ_NODE，将升级）"
        NEED_NODE=upgrade
    fi
else
    echo "❌ Node.js    未安装"
    NEED_NODE=install
fi

if command -v python3 &> /dev/null; then
    PYTHON_VER=$(python3 --version | awk '{print $2}')
    if version_ge "$PYTHON_VER" "$REQ_PYTHON"; then
        echo "✅ Python3    $PYTHON_VER（满足 ≥$REQ_PYTHON）"
    else
        echo "⚠️  Python3    $PYTHON_VER（过低，需 ≥$REQ_PYTHON，将升级）"
        NEED_PYTHON=upgrade
    fi
else
    echo "❌ Python3    未安装"
    NEED_PYTHON=install
fi

if command -v claude &> /dev/null; then
    echo "✅ Claude Code $(claude --version 2>/dev/null | head -1)（将检查更新）"
    NEED_CLAUDE=upgrade
else
    echo "❌ Claude Code 未安装"
    NEED_CLAUDE=install
fi

echo ""

# ── 预先把已有工具的路径加入当前 session ────────
# （确保后续步骤能直接使用，不依赖 source 配置文件）
command -v npm     &>/dev/null && export PATH="$(npm config get prefix)/bin:$PATH"
command -v python3 &>/dev/null && export PATH="$(python3 -m site --user-base)/bin:$PATH"

# ════════════════════════════════════════════════
# 第二步：安装 / 升级
# ════════════════════════════════════════════════
echo "【第二步】安装 / 升级..."
echo "────────────────────────────────────────"

# 设置 Homebrew 国内镜像（中科大）
export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.ustc.edu.cn/brew.git"
export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.ustc.edu.cn/homebrew-core.git"
export HOMEBREW_BOTTLE_DOMAIN="https://mirrors.ustc.edu.cn/homebrew-bottles"
export HOMEBREW_API_DOMAIN="https://mirrors.ustc.edu.cn/homebrew-bottles/api"

# ── Homebrew ──────────────────────────────────
if [ "$NEED_BREW" = true ]; then
    echo ""
    echo "📦 安装 Homebrew..."
    echo "   先测试网络连通性..."

    # 测试官方地址是否可达
    if curl -sL --connect-timeout 8 https://raw.githubusercontent.com > /dev/null 2>&1; then
        echo "   网络正常，使用官方脚本 + 中科大镜像..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    else
        echo "   官方地址不可达，使用国内备用脚本（Gitee）..."
        /bin/bash -c "$(curl -fsSL https://gitee.com/cunkai/HomebrewCN/raw/master/Homebrew.sh)"
    fi

    # 安装后立即刷新当前 session 的 PATH（关键！）
    refresh_brew_path

    if ! command -v brew &> /dev/null; then
        echo "❌ Homebrew 安装失败，请检查网络后重试"
        echo ""
        echo "    安装问题请联系客服vx：dengyi_dance"
        read -p "按回车键退出..."
        exit 1
    fi
    echo "✅ Homebrew 安装完成"
fi

# ── Git ───────────────────────────────────────
if [ "$NEED_GIT" = "install" ]; then
    echo ""; echo "📦 安装 Git..."
    brew install git
    refresh_brew_path   # 安装后刷新 PATH
elif [ "$NEED_GIT" = "upgrade" ]; then
    echo ""; echo "📦 升级 Git..."
    brew upgrade git
fi

# ── Node.js ───────────────────────────────────
if [ "$NEED_NODE" = "install" ]; then
    echo ""; echo "📦 安装 Node.js..."
    brew install node
    refresh_brew_path
    # 安装后立即把 npm 全局 bin 加入当前 session PATH
    command -v npm &>/dev/null && export PATH="$(npm config get prefix)/bin:$PATH"
elif [ "$NEED_NODE" = "upgrade" ]; then
    echo ""; echo "📦 升级 Node.js..."
    brew upgrade node
    refresh_brew_path
    command -v npm &>/dev/null && export PATH="$(npm config get prefix)/bin:$PATH"
fi

# ── Python3 ───────────────────────────────────
if [ "$NEED_PYTHON" = "install" ]; then
    echo ""; echo "📦 安装 Python3..."
    brew install python3
    refresh_brew_path
    # 安装后立即把 pip 用户包路径加入当前 session PATH
    command -v python3 &>/dev/null && export PATH="$(python3 -m site --user-base)/bin:$PATH"
elif [ "$NEED_PYTHON" = "upgrade" ]; then
    echo ""; echo "📦 升级 Python3..."
    brew upgrade python3
    command -v python3 &>/dev/null && export PATH="$(python3 -m site --user-base)/bin:$PATH"
fi

# ── Claude Code ───────────────────────────────
if [ "$NEED_CLAUDE" = "install" ]; then
    echo ""; echo "📦 安装 Claude Code（淘宝镜像）..."
    npm install -g @anthropic-ai/claude-code --registry https://registry.npmmirror.com
    if ! command -v claude &> /dev/null; then
        echo "⚠️  淘宝镜像失败，尝试官方源..."
        npm install -g @anthropic-ai/claude-code
    fi
elif [ "$NEED_CLAUDE" = "upgrade" ]; then
    echo ""; echo "📦 更新 Claude Code（淘宝镜像）..."
    npm update -g @anthropic-ai/claude-code --registry https://registry.npmmirror.com
fi

echo ""

# ════════════════════════════════════════════════
# 第三步：配置环境变量
# ════════════════════════════════════════════════
echo "【第三步】配置环境变量 → $PROFILE"
echo "────────────────────────────────────────"

# 写入文件头标记（只写一次）
if ! grep -q "# Claude Code 环境配置" "$PROFILE" 2>/dev/null; then
    printf "\n# Claude Code 环境配置 (由 setup.command 自动生成)\n" >> "$PROFILE"
fi

# 1. Homebrew PATH（Apple Silicon 必须，Intel 通常已有）
echo ""
echo "  配置 Homebrew PATH..."
add_to_profile \
    "${BREW_PREFIX}/bin/brew shellenv" \
    "eval \"\$(${BREW_PREFIX}/bin/brew shellenv)\""

# 2. Homebrew 国内镜像
echo "  配置 Homebrew 国内镜像（中科大）..."
add_to_profile \
    "HOMEBREW_BOTTLE_DOMAIN" \
    'export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.ustc.edu.cn/brew.git"
export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.ustc.edu.cn/homebrew-core.git"
export HOMEBREW_BOTTLE_DOMAIN="https://mirrors.ustc.edu.cn/homebrew-bottles"
export HOMEBREW_API_DOMAIN="https://mirrors.ustc.edu.cn/homebrew-bottles/api"'

# 3. npm 全局 bin 路径（动态获取，不硬编码）
echo "  配置 npm 全局 bin 路径..."
if command -v npm &> /dev/null; then
    NPM_BIN="$(npm config get prefix)/bin"
    export PATH="$NPM_BIN:$PATH"  # 立即在当前 session 生效
    add_to_profile \
        "npm config get prefix" \
        'export PATH="$(npm config get prefix)/bin:$PATH"'
fi

# 4. npm 淘宝镜像
echo "  配置 npm 淘宝镜像..."
if command -v npm &> /dev/null; then
    npm config set registry https://registry.npmmirror.com 2>/dev/null
    add_to_profile \
        "NPM_CONFIG_REGISTRY" \
        'export NPM_CONFIG_REGISTRY="https://registry.npmmirror.com"'
    export NPM_CONFIG_REGISTRY="https://registry.npmmirror.com"
fi

# 5. Python pip 用户包路径（pip install --user 的命令落这里）
echo "  配置 Python pip 用户包路径..."
if command -v python3 &> /dev/null; then
    PY_USER_BIN="$(python3 -m site --user-base)/bin"
    export PATH="$PY_USER_BIN:$PATH"
    add_to_profile \
        "python3 -m site --user-base" \
        'export PATH="$(python3 -m site --user-base)/bin:$PATH"'
fi

# 6. pip 阿里云镜像（写入 pip.conf，对 pip install 全局生效）
echo "  配置 pip 阿里云镜像..."
PIP_CONF="$HOME/.pip/pip.conf"
mkdir -p "$HOME/.pip"
if ! grep -qE "aliyun|tuna|ustc|npmmirror|douban" "$PIP_CONF" 2>/dev/null; then
    cat > "$PIP_CONF" << 'EOF'
[global]
index-url = https://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.aliyun.com
EOF
    echo "   ↳ 已写入 $PIP_CONF（阿里云镜像）"
else
    echo "   ↳ pip 镜像已配置，跳过"
fi

# 7. Claude Code 公司环境变量
echo "  配置 Claude Code 公司参数..."
if grep -qF "ANTHROPIC_AUTH_TOKEN" "$PROFILE" 2>/dev/null; then
    echo "   已检测到 ANTHROPIC_AUTH_TOKEN"
    read -r -n 1 -p "  是否要更新 Token？(y/N) " UPDATE_CHOICE
    echo ""
    if [[ "$UPDATE_CHOICE" =~ ^[Yy]$ ]]; then
        sed -i '' '/ANTHROPIC_AUTH_TOKEN/d' "$PROFILE"
        echo "  请输入新的 ANTHROPIC_AUTH_TOKEN（输入时不显示）："
        read -r -s -p "  Token: " USER_TOKEN
        echo ""
        if [ -n "$USER_TOKEN" ]; then
            printf '\nexport ANTHROPIC_AUTH_TOKEN="%s"\n' "$USER_TOKEN" >> "$PROFILE"
            export ANTHROPIC_AUTH_TOKEN="$USER_TOKEN"
            echo "   ↳ Token 已更新"
        else
            echo "   ↳ 未输入，保持原有 Token"
        fi
    else
        echo "   ↳ 保持原有配置"
    fi
else
    echo "  请输入您的 ANTHROPIC_AUTH_TOKEN（公司 API Key，输入时不显示）："
    read -r -s -p "  Token: " USER_TOKEN
    echo ""
    if [ -n "$USER_TOKEN" ]; then
        add_to_profile "ANTHROPIC_AUTH_TOKEN" "export ANTHROPIC_AUTH_TOKEN=\"$USER_TOKEN\""
        export ANTHROPIC_AUTH_TOKEN="$USER_TOKEN"
        echo "   ↳ ANTHROPIC_AUTH_TOKEN 已写入"
    else
        echo "   ↳ 未输入，跳过（需手动在 $PROFILE 中配置 ANTHROPIC_AUTH_TOKEN）"
    fi
fi
add_to_profile \
    "ANTHROPIC_BASE_URL" \
    'export ANTHROPIC_BASE_URL="http://xxopus.cc"
export ANTHROPIC_MODEL="xxopus-model"
export CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS=1'
export ANTHROPIC_BASE_URL="http://xxopus.cc"
export ANTHROPIC_MODEL="xxopus-model"
export CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS=1

# ── 立即让配置在当前 session 生效 ──────────────
source "$PROFILE" 2>/dev/null || true
refresh_brew_path  # source 后再刷一次确保 brew PATH 正确

echo ""

# ════════════════════════════════════════════════
# 第四步：汇总验证
# ════════════════════════════════════════════════
echo "【第四步】环境验证汇总"
echo "────────────────────────────────────────"
printf "  %-10s %s\n" "Homebrew"  "$(brew --version 2>/dev/null | head -1 || echo '❌ 未找到')"
printf "  %-10s %s\n" "Git"       "$(git --version 2>/dev/null | awk '{print $3}' || echo '❌ 未找到')"
printf "  %-10s %s\n" "Node.js"   "$(node --version 2>/dev/null || echo '❌ 未找到')"
printf "  %-10s %s\n" "npm"       "$(npm --version 2>/dev/null || echo '❌ 未找到')"
printf "  %-10s %s\n" "Python3"   "$(python3 --version 2>/dev/null | awk '{print $2}' || echo '❌ 未找到')"
printf "  %-10s %s\n" "pip3"      "$(pip3 --version 2>/dev/null | awk '{print $2}' || echo '❌ 未找到')"
printf "  %-10s %s\n" "Claude"    "$(claude --version 2>/dev/null | head -1 || echo '❌ 未找到')"
echo ""
echo "  Shell配置：$PROFILE"
echo "  pip 镜像 ：$HOME/.pip/pip.conf（阿里云）"
echo ""
echo "============================================"
if command -v claude &> /dev/null; then
    echo "    ✅ 全部完成！"
    echo "    建议重新打开终端让配置完全生效"
    echo "    然后双击 claude.command 启动"
else
    echo "    ⚠️  Claude Code 未安装成功"
    echo "    请检查上方错误信息，或重新运行脚本"
    echo ""
    echo "    安装问题请联系客服vx：dengyi_dance"
fi
echo "============================================"
echo ""

# ════════════════════════════════════════════════
# 安装总结（手动卸载参考）
# ════════════════════════════════════════════════
echo "────────────────────────────────────────"
echo "  📋 安装总结（如需手动清理，请参考此信息）"
echo "────────────────────────────────────────"
echo ""
echo "  ── 工具安装情况 ──"
if [ "$NEED_BREW" = true ]; then
    echo "  ✅ Homebrew     新安装 → $BREW_PREFIX"
else
    echo "  ○  Homebrew     已存在，未改动"
fi
if [ "$NEED_GIT" = "install" ]; then
    echo "  ✅ Git          新安装 → $(which git 2>/dev/null)"
elif [ "$NEED_GIT" = "upgrade" ]; then
    echo "  ✅ Git          已升级 → $(which git 2>/dev/null)"
else
    echo "  ○  Git          已存在，未改动"
fi
if [ "$NEED_NODE" = "install" ]; then
    echo "  ✅ Node.js      新安装 → $(which node 2>/dev/null)"
elif [ "$NEED_NODE" = "upgrade" ]; then
    echo "  ✅ Node.js      已升级 → $(which node 2>/dev/null)"
else
    echo "  ○  Node.js      已存在，未改动"
fi
if [ "$NEED_PYTHON" = "install" ]; then
    echo "  ✅ Python3      新安装 → $(which python3 2>/dev/null)"
elif [ "$NEED_PYTHON" = "upgrade" ]; then
    echo "  ✅ Python3      已升级 → $(which python3 2>/dev/null)"
else
    echo "  ○  Python3      已存在，未改动"
fi
if [ "$NEED_CLAUDE" = "install" ]; then
    echo "  ✅ Claude Code  新安装 → $(which claude 2>/dev/null)"
elif [ "$NEED_CLAUDE" = "upgrade" ]; then
    echo "  ✅ Claude Code  已更新 → $(which claude 2>/dev/null)"
fi
echo ""
echo "  ── 修改的文件 ──"
echo "  📄 $PROFILE"
echo "     新增内容：ANTHROPIC_AUTH_TOKEN / ANTHROPIC_BASE_URL /"
echo "               ANTHROPIC_MODEL / CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS"
echo "               Homebrew PATH & 镜像 / npm PATH & 镜像 / Python PATH"
if [ -f "$HOME/.pip/pip.conf" ] && grep -q "aliyun" "$HOME/.pip/pip.conf" 2>/dev/null; then
    echo "  📄 ~/.pip/pip.conf"
    echo "     新增内容：pip 阿里云镜像（index-url）"
fi
if command -v npm &>/dev/null; then
    echo "  📄 $(npm config get userconfig 2>/dev/null || echo '~/.npmrc')"
    echo "     新增内容：npm registry = 淘宝镜像"
fi
echo ""
echo "  ── 卸载方式 ──"
echo "  • 双击 uninstall.command 自动清理"
echo "  • 或手动从上述文件中删除对应内容"
echo "────────────────────────────────────────"
echo ""
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    read -p "按回车键退出..."
fi
